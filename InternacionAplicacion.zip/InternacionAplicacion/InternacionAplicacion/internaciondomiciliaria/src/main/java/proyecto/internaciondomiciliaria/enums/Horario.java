package proyecto.internaciondomiciliaria.enums;

import java.util.LinkedHashMap;

import java.util.Map;

public class Horario {
    public Map<Integer, String> getHorarios() {
        {
            Map<Integer, String> map = new LinkedHashMap();
            map.put(1, "08:00");
            map.put(2, "09:00");
            map.put(3, "10:00");
            map.put(4, "11:00");
            map.put(5, "12:00");
            map.put(6, "13:00");
            return map;

        }
    }
}

package proyecto.internaciondomiciliaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternaciondomiciliariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternaciondomiciliariaApplication.class, args);
	}

}
